#!/usr/bin/env bash

for dotfile in *.dot; do
    dot \
      -Grankdir="LR" \
      -Nfontname="arial" \
      -Nfontsize=12.0 \
      -Nshape=record \
      -Earrowsize=0.5 \
      -Efontname="arial" \
      -Efontsize=10.0 \
      -Tsvg \
      $dotfile -o $(basename $dotfile .dot).svg
done